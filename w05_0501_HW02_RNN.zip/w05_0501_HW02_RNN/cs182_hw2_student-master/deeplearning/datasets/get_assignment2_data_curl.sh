#!/bin/bash
./get_coco_captioning_curl.sh
./get_squeezenet_tf_curl.sh
./get_imagenet_val_curl.sh

