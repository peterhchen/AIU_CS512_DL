# Neural Networks from Scratch (NNFS) book code

The NNFS book is written with the Python programming lanauge. If you're interested in seeing this same content, but with 40+ other programming languages,

