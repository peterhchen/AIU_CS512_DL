rm hw3_submission.zip
zip hw3_submission.zip -r *.py *.ipynb submission_logs best_models
