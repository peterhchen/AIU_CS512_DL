'''
https://blog.paperspace.com/getting-started-with-openai-gym/
conda has crash in 
libGL error: MESA-LOADER: failed to open iris: /usr/lib/dri/iris_dri.so:
https://stackoverflow.com/questions/71010343/cannot-load-swrast-and-iris-drivers-in-fedora-35/72200748#72200748
conda install -c conda-forge libstdcxx-n
'''
import numpy as np
import gym

# Import and initialize Mountain Car Environment
# render_mode="huma" open an window to display.

env = gym.make('MountainCar-v0', render_mode="human")

env.reset()

LEARNING_RATE = 0.1
DISCOUNT = 0.95
EPISODES = 250000000000
SHOW_EVERY = 200000000

DISCRETE_OS_SIZE = [20] * len (env.observation_space.high)
discrete_os_win_size = (env.observation_space.high - env.observation_space.low)/DISCRETE_OS_SIZE

q_table = np.random.uniform(low=-2, high=0, size = (DISCRETE_OS_SIZE + [env.action_space.n])) 

def get_discrete_state (state):
    discrete_state = (state - env.observation_space.low) / discrete_os_win_size
    """
    print('**************************************************')
    print('state:', state)
    print('env.observation_space.low:', env.observation_space.low)
    print('discrete_os_win_size:', discrete_os_win_size)
    print('discrete_state:', discrete_state)
    print('tuple(discrete_state.astype(int):', tuple(discrete_state.astype(int)))
    """
    return tuple(discrete_state.astype(int))  # change np.int to int after numpy 1.24.



#print('**reset_state:', reset_state)
print('**reset_state[0]:', reset_state[0])
discrete_state = get_discrete_state (reset_state[0])
print('*****discrete_state:', discrete_state)
done = False
i = 0

for episode in range (EPISODES):
    if episode % SHOW_EVERY == 0:
        render = True
    else:
        render = False
    
    while not done:
        action = np.argmax(q_table[discrete_state])  
        new_state, reward, done, _, _ = env.step(action)
        new_discrete_state = get_discrete_state(new_state)
        # print('  ## while action:', action)
        if render:
            env.render()
        if not done:
            #print('    #### if new_discrete_state:', new_discrete_state)
            max_future_q = np.max(q_table[new_discrete_state])
            q_table_index = discrete_state + (action, )
            # current_q = q_table[discrete_state + (action, )]
            current_q = q_table[q_table_index]
            #print('    #### if q_table_index:', q_table_index)
            new_q = (1 - LEARNING_RATE) * current_q + LEARNING_RATE * (reward + DISCOUNT * max_future_q)
            """
            print('    #### if max_future_q:', max_future_q)
            print('    #### if current_q:', current_q)
            print('    #### if reward:', reward)
            print('    #### if new_q:', new_q)
            """
            q_table[discrete_state + (action, )] = new_q
            """
            print('    #### if q_table[q_table_index]:', q_table[q_table_index])
            print('    #### if q_table.shape:', q_table.shape)
            print('    #### if q_table[:1]:')
            """

        elif new_state[0] >= env.goal_position:
            print ("We made it on episode { episode }")
            q_table[discrete_state + (action,)] = 0
        
        discrete_state = new_discrete_state
        #if i >= 0:
        #    break
        i += 1

env.close()

