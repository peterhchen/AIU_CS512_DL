import numpy as np
import cv2

img = cv2.imread('assets/soccer_practice.jpg', 0)
template = cv2.imread('assets/shoe.PNG', 0)
h, w = template.shape
print('base (h, w):', img.shape)
print('template (h, w):', template.shape)
# Different ways of template matching
methods = [cv2.TM_CCOEFF, cv2.TM_CCOEFF_NORMED, cv2.TM_CCORR,
            cv2.TM_CCORR_NORMED, cv2.TM_SQDIFF, cv2.TM_SQDIFF_NORMED]
print ('methods:', methods)
# We loop for the methods.
for method in methods:
    img2 = img.copy()

    result = cv2.matchTemplate(img2, template, method)
    # result: value at (W - w + 1, H - h + 1)
    # W, H: base; w, h: template
    print('method:', method)
    print('result:', result)
