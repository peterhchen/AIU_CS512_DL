import numpy as np
import cv2
# 0: grayscale
img = cv2.imread('assets/soccer_practice.jpg', 0)
template = cv2.imread('assets/shoe.PNG', 0)
# copy the image
img2 = img.copy()

bh, bw = img.shape
th, tw = template.shape
print('img:')  # image 2-D grayscale (not 3-D [H, W, Chan]) arraymv 
print(img)
print('base-height, base-width:', bh, bw)
print('template:')
print(template)
print('template-height, template-width:', th, tw)