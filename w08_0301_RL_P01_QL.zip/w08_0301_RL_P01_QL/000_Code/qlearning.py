'''
https://blog.paperspace.com/getting-started-with-openai-gym/
'''
import gym

# Import and initialize Mountain Car Environment
# render_mode="huma" open an window to display.
env = gym.make('MountainCar-v0', render_mode="human")
env.reset()

DISCRETE_OS_SIZE = [20] * len (env.observation_space.high)
discrete_os_win_size = (env.observation_space.high - env.observation_space.low)/DISCRETE_OS_SIZE
print('*********************************************')
print('env.observation_space.high:', env.observation_space.high)
print('len(env.observation_space.high):', len(env.observation_space.high))
print('env.observation_space.low:', env.observation_space.low)
print('env.action_space:', env.action_space)
print('DISCRETE_OS_SIZE :', DISCRETE_OS_SIZE)
print('discrete_os_win_size :', discrete_os_win_size)
print('*********************************************')
'''
*********************************************
env.observation_space.high: [0.6  0.07]
len(env.observation_space.high): 2
env.observation_space.low: [-1.2  -0.07]
env.action_space: Discrete(3)
DISCRETE_OS_SIZE : [20, 20]
discrete_os_win_size : [0.09  0.007]
*********************************************
'''
# we need to print out the reward before we initialze the reasonable values
import numpy as np
q_table = np.random.uniform(low=-2, high=0, size = (DISCRETE_OS_SIZE + [env.action_space.n])) 
print('DISCRETE_OS_SIZE :', DISCRETE_OS_SIZE)
print('[env.action_space.n]:', [env.action_space.n])
print('DISCRETE_OS_SIZE + [env.action_space.n]:', DISCRETE_OS_SIZE + [env.action_space.n])
print('env.action_space.n:', env.action_space.n)
print('q_table.shape:', q_table.shape)
print('q_table[:1]:')
print(q_table[:1])
'''
DISCRETE_OS_SIZE : [20, 20]
[env.action_space.n]: [3]
DISCRETE_OS_SIZE + [env.action_space.n]: [20, 20, 3]
env.action_space.n: 3
q_table.shape: (20, 20, 3)
'''
done = False

while not done:
    action = 2
    new_state, reward, done, _, _ = env.step(action)
    # print ("new_state:", new_state)
    # print("reward:", reward)
    env.render()

env.close()
